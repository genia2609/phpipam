<?php

/**
 * Script to display available VLANs
 */

include(dirname(__FILE__) . "/../../tools/vlan/index.php");

?>
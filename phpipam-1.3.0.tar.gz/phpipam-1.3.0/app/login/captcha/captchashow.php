<?php
include 'captcha.php';
$img = new securimage();
//show image
$img->show();
?>

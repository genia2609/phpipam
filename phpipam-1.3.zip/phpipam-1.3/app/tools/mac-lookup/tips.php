<?php

/*
 * sime search tips....
 **************************/
?>

<h4><?php print _('Decode tips');?></h4>
<hr>

<div class="alert alert-block alert-info">
<?php print _("Enter MAC address in one of the following formats:"); ?>
<ul>
	<li>00:50:56:93:73:f4</li>
	<li>00-50-56-93-73-f4</li>
	<li>0050.5693.73f4</li>
	<li>0050569373f4</li>
</ul>

</div>